"""External MQTT observer/command driver; never imports or replaces the simulator."""
import json
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt

out = Path(sys.argv[1])
packets = []
condition = threading.Condition()
log = (out / "mqtt.ndjson").open("w", encoding="utf-8")
summary = {"trials": [], "start_utc": datetime.now(timezone.utc).isoformat()}


def inspect():
    value = json.loads(subprocess.check_output(["docker", "inspect", "jspx-sim-1"]))[0]
    return {"container": value["Id"], "image": value["Image"],
            "started_at": value["State"]["StartedAt"],
            "restarts": value["RestartCount"], "command": value["Config"]["Cmd"]}


def receive(client, userdata, message):
    raw = message.payload.decode("utf-8")
    try:
        payload = json.loads(raw, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    except json.JSONDecodeError:
        payload = raw
    record = {"received_utc": datetime.now(timezone.utc).isoformat(),
              "monotonic": time.monotonic(), "topic": message.topic,
              "retain": message.retain, "payload": payload}
    with condition:
        packets.append(record)
        log.write(json.dumps(record, allow_nan=False) + "\n")
        log.flush()
        condition.notify_all()


def wait_packet(predicate, after, timeout=12):
    deadline = time.monotonic() + timeout
    with condition:
        while True:
            for packet in packets[after:]:
                if predicate(packet):
                    return packet
            left = deadline - time.monotonic()
            if left <= 0:
                raise AssertionError("Timed out waiting for MQTT observation")
            condition.wait(left)


def status(packet, breaker, state, tripped):
    p = packet["payload"]
    return (packet["topic"] == "status/breaker/" + breaker
            and p["state"] == state and p["tripped"] is tripped)


def command(topic, payload=""):
    start = len(packets)
    client.publish(topic, payload, qos=0, retain=False).wait_for_publish()
    wait_packet(lambda p: p["topic"] == topic, start)
    return start


def operation(breaker, action, state, tripped):
    start = command(f"cmd/breaker/{breaker}/{action}")
    return wait_packet(lambda p: status(p, breaker, state, tripped), start)


def telemetry(after, energized):
    return wait_packet(lambda p: p["topic"] == "telemetry/pandapower" and any(
        b["name"] == "BUS_SS1_LV" and b["energized"] is energized
        for b in p["payload"]["buses"]), after)


def restore():
    command("cmd/sim/scenario/set", "NORMAL")
    operation("BRK_R1", "reset", "CLOSED", False)
    operation("BRK_F1", "reset", "OPEN", False)
    operation("BRK_R1", "open", "OPEN", False)
    operation("BRK_R1", "close", "CLOSED", False)
    index = len(packets)
    operation("BRK_F1", "close", "CLOSED", False)
    telemetry(index, True)


client = mqtt.Client(client_id="issue21-observer", clean_session=True)
client.on_message = receive
client.connect("127.0.0.1", 1883)
client.subscribe([("status/breaker/#", 0), ("event/ied", 0),
                  ("telemetry/pandapower", 0), ("cmd/#", 0)])
client.loop_start()
try:
    summary["runtime_before"] = inspect()
    command("cmd/sim/scenario/set", "NORMAL")
    # Explicit, reversible starting-state operations through the real runtime.
    operation("BRK_R1", "reset", "CLOSED", False)
    operation("BRK_F1", "reset", "CLOSED", False)
    operation("BRK_R1", "close", "CLOSED", False)
    operation("BRK_F1", "close", "CLOSED", False)
    telemetry(0, True)

    for offset in (0.05, 0.85, 0.98):
        before = len(packets)
        publication = telemetry(before, True)
        time.sleep(max(0, publication["monotonic"] + offset - time.monotonic()))
        start = command("cmd/sim/scenario/set", "R1_OPENING_FAILURE_TEST")
        sent = wait_packet(lambda p: p["topic"] == "cmd/sim/scenario/set", start)
        primary = wait_packet(lambda p: status(p, "BRK_R1", "CLOSED", True), start)
        backup = wait_packet(lambda p: status(p, "BRK_F1", "OPEN", True), start)
        isolated = telemetry(start, False)
        lv = next(b for b in isolated["payload"]["buses"] if b["name"] == "BUS_SS1_LV")
        assert lv["vm_pu"] is None and lv["quality"] == "NOT_ENERGIZED"
        # Keep diagnostics active over several regular publication points.
        time.sleep(3.2)
        trial_packets = packets[start:]
        events = [p["payload"] for p in trial_packets if p["topic"] == "event/ied"]
        pickups = {p["breaker"]: p["scan_monotonic_s"] for p in events if p["event"] == "PICKUP"}
        trips = {p["breaker"]: p["scan_monotonic_s"] for p in events if p["event"] == "TRIP_REQUEST"}
        failed = next(p for p in events if p["event"] == "POSITION_FEEDBACK"
                      and p["breaker"] == "BRK_R1")
        assert failed["success"] is False and failed["actual_state"] == "CLOSED"
        assert primary["monotonic"] < backup["monotonic"]
        for breaker, state in (("BRK_R1", "CLOSED"), ("BRK_F1", "OPEN")):
            rejection = operation(breaker, "close", state, True)
            assert rejection["payload"]["tripped"] is True
        normal_start = command("cmd/sim/scenario/set", "NORMAL")
        telemetry(normal_start, False)
        # CLOSE is still rejected after NORMAL; neither latch nor position changed.
        operation("BRK_R1", "close", "CLOSED", True)
        operation("BRK_F1", "close", "OPEN", True)
        trial = {
            "requested_offset_s": offset,
            "observed_command_offset_s": sent["monotonic"] - publication["monotonic"],
            "command_utc": sent["received_utc"],
            "trip_elapsed_s": {b: trips[b] - pickups[b] for b in trips},
            "failed_r1_feedback": failed,
            "r1_status": primary["payload"], "f1_status": backup["payload"],
            "isolated_lv": lv,
            "diagnostic_publications": sum(p["topic"] == "telemetry/pandapower" for p in trial_packets),
            "close_rejected_before_and_after_normal": True,
        }
        restore()
        trial["reset_without_movement_and_refusal_removed"] = True
        summary["trials"].append(trial)
        print(json.dumps(trial, allow_nan=False), flush=True)

    # Additional regular-runtime diagnostic observations.
    start = command("cmd/sim/scenario/set", "TAIL_OVERCURRENT_TEST")
    wait_packet(lambda p: status(p, "BRK_R1", "OPEN", True), start)
    telemetry(start, False)
    command("cmd/sim/scenario/set", "NORMAL")
    operation("BRK_R1", "reset", "OPEN", False)
    operation("BRK_R1", "close", "CLOSED", False)
    telemetry(len(packets), True)
    start = command("cmd/sim/scenario/set", "LOW_SOURCE_VOLTAGE")
    wait_packet(lambda p: p["topic"] == "status/breaker/BRK_F1"
                and p["payload"]["undervoltage_alarm"] is True, start)
    time.sleep(2.2)
    start = command("cmd/sim/scenario/set", "NORMAL")
    wait_packet(lambda p: p["topic"] == "status/breaker/BRK_F1"
                and p["payload"]["undervoltage_alarm"] is False, start)
    telemetry(start, True)
    summary["selective_trip_and_low_source_alarm"] = True
    summary["runtime_after"] = inspect()
    assert summary["runtime_before"] == summary["runtime_after"]
    summary["event_run_ids"] = sorted({p["payload"]["event_id"].split(":")[0]
        for p in packets if p["topic"] == "event/ied"})
    assert len(summary["event_run_ids"]) == 1
    summary["result"] = "passed"
finally:
    summary["end_utc"] = datetime.now(timezone.utc).isoformat()
    (out / "live-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    client.loop_stop()
    client.disconnect()
    log.close()
