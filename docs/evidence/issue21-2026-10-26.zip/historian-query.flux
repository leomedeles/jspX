from(bucket: "scada")
  |> range(start: time(v: "2026-10-26T20:48:38.594597+00:00"), stop: time(v: "2026-10-26T20:49:07.341544+00:00"))
  |> filter(fn: (r) => r._measurement == "ied_event" or r._measurement == "breaker_status" or r._measurement == "bus" or r._measurement == "line")
  |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
