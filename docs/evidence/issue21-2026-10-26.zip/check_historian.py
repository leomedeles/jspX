"""Read-only comparison of real MQTT observations with persisted Influx rows."""
import csv
import io
import json
import sys
import urllib.request
from pathlib import Path

out = Path(sys.argv[1])
summary = json.loads((out / "live-summary.json").read_text())
packets = [json.loads(line) for line in (out / "mqtt.ndjson").read_text().splitlines()]
env = {}
for line in Path(".env").read_text().splitlines():
    if line.strip() and not line.lstrip().startswith("#") and "=" in line:
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")

flux = '''from(bucket: "%s")
  |> range(start: time(v: "%s"), stop: time(v: "%s"))
  |> filter(fn: (r) => r._measurement == "ied_event" or r._measurement == "breaker_status" or r._measurement == "bus" or r._measurement == "line")
  |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
''' % (env.get("INFLUXDB_BUCKET", "scada"), summary["start_utc"], summary["end_utc"])
(out / "historian-query.flux").write_text(flux)
request = urllib.request.Request("http://127.0.0.1:8086/api/v2/query?org=jspX",
    data=flux.encode(), headers={"Authorization": "Token " + env["INFLUXDB_ADMIN_TOKEN"],
        "Accept": "application/csv", "Content-Type": "application/vnd.flux"})
with urllib.request.urlopen(request, timeout=20) as response:
    raw = response.read().decode()
(out / "historian.csv").write_text(raw)
rows, header = [], None
for line in csv.reader(io.StringIO(raw)):
    if not line or line[0].startswith("#"):
        continue
    if "_measurement" in line and "_time" in line:
        header = line
    elif header is not None:
        rows.append(dict(zip(header, line)))

events = [p["payload"] for p in packets if p["topic"] == "event/ied"]
stored_events = [r for r in rows if r["_measurement"] == "ied_event"]
event_ids = {p["event_id"] for p in events}
stored_ids = {r["event_id"] for r in stored_events}
assert event_ids == stored_ids, {"missing": sorted(event_ids - stored_ids),
                                "extra": sorted(stored_ids - event_ids)}
assert len(event_ids) == len(events) == len(stored_events)
for event in events:
    row = next(r for r in stored_events if r["event_id"] == event["event_id"])
    for field in ("event", "breaker", "ied", "position"):
        assert row[field] == event[field]
    assert row["tripped"] == str(event["tripped"]).lower()
    if "success" in event:
        assert row["success"] == str(event["success"]).lower()
        assert row["actual_state"] == event["actual_state"]

for trial in summary["trials"]:
    for status in (trial["r1_status"], trial["f1_status"]):
        assert any(r["_measurement"] == "breaker_status" and r["breaker"] == status["breaker"]
                   and r["state"] == status["state"] and r["tripped"] == "true" for r in rows)
    # Match the millisecond timestamp of each specific failed-opening status.
    for key in ("r1_status", "f1_status"):
        status = trial[key]
        from datetime import datetime
        ts = datetime.fromisoformat(status["ts"].replace("Z", "+00:00"))
        assert any(r["_measurement"] == "breaker_status" and r["breaker"] == status["breaker"]
                   and datetime.fromisoformat(r["_time"].replace("Z", "+00:00")) == ts
                   and r["state"] == status["state"] and r["tripped"] == "true" for r in rows)

isolated = [r for r in rows if r["_measurement"] == "bus" and r.get("name") == "BUS_SS1_LV"
            and r.get("energized") == "false" and r.get("quality") == "NOT_ENERGIZED"]
assert isolated and all(not r.get("vm_pu") for r in isolated)
open_lines = [r for r in rows if r["_measurement"] == "line" and r.get("name") == "L1_FEEDER_HEAD"
              and r.get("energized") == "false"]
assert open_lines and all(float(r["i_ka"]) == 0 for r in open_lines)
result = {"mqtt_events": len(events), "stored_event_rows": len(stored_events),
          "missing_or_overwritten_events": 0, "unique_event_ids": len(event_ids),
          "failed_opening_status_pairs_matched_by_timestamp": len(summary["trials"]),
          "isolated_lv_rows": len(isolated), "open_f1_line_rows": len(open_lines),
          "result": "passed", "dashboard_visual": "blocked by Computer Use URL confidence policy"}
(out / "historian-summary.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result))
